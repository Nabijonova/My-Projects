﻿/*
 * Created by SharpDevelop.
 * User: User
 * Date: 25/09/2019
 * Time: 20:48
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace kv_tenglama
{
	partial class MainForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.Label a;
		private System.Windows.Forms.Label xbir;
		private System.Windows.Forms.Label c;
		private System.Windows.Forms.Label b;
		private System.Windows.Forms.Label xikki;
		private System.Windows.Forms.Button tugma;
		private System.Windows.Forms.TextBox asoni;
		private System.Windows.Forms.TextBox x2qiymat;
		private System.Windows.Forms.TextBox x1qiymat;
		private System.Windows.Forms.TextBox csoni;
		private System.Windows.Forms.TextBox bsoni;
		private System.Windows.Forms.Label hato;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.a = new System.Windows.Forms.Label();
			this.xbir = new System.Windows.Forms.Label();
			this.c = new System.Windows.Forms.Label();
			this.b = new System.Windows.Forms.Label();
			this.xikki = new System.Windows.Forms.Label();
			this.tugma = new System.Windows.Forms.Button();
			this.asoni = new System.Windows.Forms.TextBox();
			this.x2qiymat = new System.Windows.Forms.TextBox();
			this.x1qiymat = new System.Windows.Forms.TextBox();
			this.csoni = new System.Windows.Forms.TextBox();
			this.bsoni = new System.Windows.Forms.TextBox();
			this.hato = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// a
			// 
			this.a.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
			this.a.Location = new System.Drawing.Point(12, 35);
			this.a.Name = "a";
			this.a.Size = new System.Drawing.Size(207, 38);
			this.a.TabIndex = 0;
			this.a.Text = "A ni kiriting:";
			this.a.Click += new System.EventHandler(this.Label1Click);
			// 
			// xbir
			// 
			this.xbir.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
			this.xbir.Location = new System.Drawing.Point(12, 330);
			this.xbir.Name = "xbir";
			this.xbir.Size = new System.Drawing.Size(103, 38);
			this.xbir.TabIndex = 1;
			this.xbir.Text = "x1";
			// 
			// c
			// 
			this.c.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
			this.c.Location = new System.Drawing.Point(12, 166);
			this.c.Name = "c";
			this.c.Size = new System.Drawing.Size(207, 38);
			this.c.TabIndex = 2;
			this.c.Text = "C ni kiriting:";
			// 
			// b
			// 
			this.b.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
			this.b.Location = new System.Drawing.Point(12, 99);
			this.b.Name = "b";
			this.b.Size = new System.Drawing.Size(207, 38);
			this.b.TabIndex = 3;
			this.b.Text = "B ni kiriting:";
			// 
			// xikki
			// 
			this.xikki.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
			this.xikki.Location = new System.Drawing.Point(12, 401);
			this.xikki.Name = "xikki";
			this.xikki.Size = new System.Drawing.Size(103, 38);
			this.xikki.TabIndex = 4;
			this.xikki.Text = "x2";
			// 
			// tugma
			// 
			this.tugma.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
			this.tugma.Location = new System.Drawing.Point(63, 231);
			this.tugma.Name = "tugma";
			this.tugma.Size = new System.Drawing.Size(406, 67);
			this.tugma.TabIndex = 5;
			this.tugma.Text = "Natija uchun bosing!";
			this.tugma.UseVisualStyleBackColor = true;
			this.tugma.Click += new System.EventHandler(this.TugmaClick);
			// 
			// asoni
			// 
			this.asoni.Location = new System.Drawing.Point(384, 45);
			this.asoni.Name = "asoni";
			this.asoni.Size = new System.Drawing.Size(85, 26);
			this.asoni.TabIndex = 6;
			// 
			// x2qiymat
			// 
			this.x2qiymat.Location = new System.Drawing.Point(174, 411);
			this.x2qiymat.Name = "x2qiymat";
			this.x2qiymat.Size = new System.Drawing.Size(85, 26);
			this.x2qiymat.TabIndex = 7;
			// 
			// x1qiymat
			// 
			this.x1qiymat.Location = new System.Drawing.Point(174, 340);
			this.x1qiymat.Name = "x1qiymat";
			this.x1qiymat.Size = new System.Drawing.Size(85, 26);
			this.x1qiymat.TabIndex = 8;
			// 
			// csoni
			// 
			this.csoni.Location = new System.Drawing.Point(384, 176);
			this.csoni.Name = "csoni";
			this.csoni.Size = new System.Drawing.Size(85, 26);
			this.csoni.TabIndex = 9;
			this.csoni.TextChanged += new System.EventHandler(this.CsoniTextChanged);
			// 
			// bsoni
			// 
			this.bsoni.Location = new System.Drawing.Point(384, 109);
			this.bsoni.Name = "bsoni";
			this.bsoni.Size = new System.Drawing.Size(85, 26);
			this.bsoni.TabIndex = 10;
			// 
			// hato
			// 
			this.hato.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
			this.hato.Location = new System.Drawing.Point(12, 485);
			this.hato.Name = "hato";
			this.hato.Size = new System.Drawing.Size(457, 38);
			this.hato.TabIndex = 11;
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(532, 581);
			this.Controls.Add(this.hato);
			this.Controls.Add(this.bsoni);
			this.Controls.Add(this.csoni);
			this.Controls.Add(this.x1qiymat);
			this.Controls.Add(this.x2qiymat);
			this.Controls.Add(this.asoni);
			this.Controls.Add(this.tugma);
			this.Controls.Add(this.xikki);
			this.Controls.Add(this.b);
			this.Controls.Add(this.c);
			this.Controls.Add(this.xbir);
			this.Controls.Add(this.a);
			this.Name = "MainForm";
			this.Text = "kv_tenglama";
			this.ResumeLayout(false);
			this.PerformLayout();

		}
	}
}
