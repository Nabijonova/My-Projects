﻿/*
 * Created by SharpDevelop.
 * User: User
 * Date: 25/09/2019
 * Time: 20:48
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace kv_tenglama
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		void Label1Click(object sender, EventArgs e)
		{
	
		}
		void TugmaClick(object sender, EventArgs e)
		{
			double d,a,b,c,x1,x2;
			b=double.Parse(bsoni.Text);
			a=double.Parse(asoni.Text);
			c=double.Parse(csoni.Text);
			d=b*b-4*a*c;x1qiymat.Clear();x2qiymat.Clear();hato.Text="";
			if(d>=0&&a!=0&b!=0&c!=0) 
			{
				//x1qiymat.Clear();x2qiymat.Clear();hato.Text="";
				x1=(-b+Math.Sqrt(d))/(2*a);x2=(-b-Math.Sqrt(d))/(2*a);
				x1qiymat.Text=x1.ToString();
				x2qiymat.Text=x2.ToString();
			}
			else 
			{
				//x1qiymat.Clear();x2qiymat.Clear();
				if(a==0) 
				  {x1=-c/b;x1qiymat.Text=x1.ToString();}
				else 
				{
					if(b==0&((c<=0&a>0)|(c>=0&a<0))) 
					{ 
						//x1qiymat.Clear();x2qiymat.Clear();
						x1=Math.Sqrt(-c/a); x2=-x1;
						x1qiymat.Text=x1.ToString();
				        x2qiymat.Text=x2.ToString();
					}
					else if(c==0) 
					{
					   x1=0;x2=-b/a;
				       x1qiymat.Text=x1.ToString();
				       x2qiymat.Text=x2.ToString();
					}
					else hato.Text="Yechimga ega emas!";
				}
			}
		}
		void CsoniTextChanged(object sender, EventArgs e)
		{
	
		}
	}
}
