﻿/*
 * Created by SharpDevelop.
 * User: User
 * Date: 05/06/2019
 * Time: 20:39
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace string_27
{
	class Program
	{
		public static void Main(string[] args)
		{
			int n1,n2,n=0,i=0; string s1,s2,c=""; 
            Console.Write("Birinchi sonni kiriting: ");
            n1=Convert.ToInt32(Console.ReadLine());
            Console.Write("Ikkinchi sonni kiriting: ");
            n2=Convert.ToInt32(Console.ReadLine());
            Console.Write("Birinchi satrni kiriting: ");
            s1=Console.ReadLine();
            Console.Write("Ikkinchi satrni kiriting: ");
            s2=Console.ReadLine();
            for(i=0;i<n1;i++) c+=s1[i];
            for(i=s2.Length-1;i>=s2.Length-n2;i--) c+=s2[i];
            Console.Write("Natija: "+c);
			Console.ReadKey(true);
		}
	}
}