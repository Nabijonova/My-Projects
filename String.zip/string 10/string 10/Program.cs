﻿/*
 * Created by SharpDevelop.
 * User: User
 * Date: 27/03/2019
 * Time: 19:45
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace string_10
{
	class Program
	{
		public static void Main(string[] args)
		{
			string s,P=" ";
			Console.WriteLine("Satr uchun belgilar kiriting: ");
			s=Console.ReadLine();
			for(int i=s.Length-1;i>=0;i--)
			{
				P+=s[i];
			}
			Console.WriteLine("Natija: "+P);
			Console.ReadKey(true);
		}
	}
}