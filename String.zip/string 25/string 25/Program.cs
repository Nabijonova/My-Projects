﻿/*
 * Created by SharpDevelop.
 * User: User
 * Date: 05/06/2019
 * Time: 20:09
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace string_25
{
	class Program
	{
		public static void Main(string[] args)
		{
			int m,n; string s,a=""; 
            Console.Write("O'nlik sanoq sistemasidagi natural sonni bildiradigan satr kiriting: ");
            s=Console.ReadLine();
            m=Convert.ToInt32(s);
            for(int i=m;i>0;i--)
            {
            	n=m%2;
            	if(n==0) a="0"+a;else a="1"+a;
            	m=m/2;
            }
            m=Convert.ToInt32(a);
            Console.Write("Natija: "+m);
			Console.ReadKey(true);
		}
	}
}