﻿/*
 * Created by SharpDevelop.
 * User: User
 * Date: 26/03/2019
 * Time: 10:56
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace string_4
{
	class Program
	{
		public static void Main(string[] args)
		{
			int a;			
			Console.Write("Chiqarilishi kerak bo'lgan belgilar sonini kiriting: ");
			a=int.Parse(Console.ReadLine());
			if(a>0&a<27)
			{
			 for(int i=0;i<a;i++)
			 {
				Console.WriteLine((char)(65+i));
			 }
			}
			else Console.Write("Chiqarilishi kerak bo'lgan belgilar soni qayta kiritilsin!");
			Console.ReadKey(true);
		}
	}
}