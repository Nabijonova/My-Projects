﻿/*
 * Created by SharpDevelop.
 * User: User
 * Date: 28/03/2019
 * Time: 07:00
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace string_13
{
	class Program
	{
		public static void Main(string[] args)
		{
			Console.WriteLine("Hello World!");
			
			Console.ReadKey(true);
		}
	}
}