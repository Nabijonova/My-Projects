﻿/*
 * Created by SharpDevelop.
 * User: User
 * Date: 05/06/2019
 * Time: 20:59
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace string_29
{
	class Program
	{
		public static void Main(string[] args)
		{
			            string S,c=""; char C; 
            Console.Write("Belgi kiriting: ");
            C=Convert.ToChar(Console.ReadLine());
            Console.Write("Satr kiriting: ");
            S=Console.ReadLine();
            for (int i=0;i<S.Length;i++)
            {
                if ((int)S[i]==C) c+=S[i];
                c+=S[i];
            }
            Console.Write("Hosil bo'lgan yangi satr: "+c);
            Console.ReadKey(true);

		}
	}
}