﻿/*
 * Created by SharpDevelop.
 * User: User
 * Date: 28/03/2019
 * Time: 06:20
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace string_11
{
	class Program
	{
		public static void Main(string[] args)
		{
		    string s,P="" ;
			Console.Write("Satr uchun belgilar kiriting: ");
			s=Console.ReadLine();
			for(int i=0;i<s.Length;i++)
			{
				P+=s[i]+" ";
			}
			Console.WriteLine("Natija: "+P);			
			Console.ReadKey(true);
		}
	}
}