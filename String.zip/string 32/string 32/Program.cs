﻿/*
 * Created by SharpDevelop.
 * User: User
 * Date: 12/06/2019
 * Time: 22:33
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace string_32
{
	class Program
	{
		public static void Main(string[] args)
		{
			string S,S0; bool f=false; int n=0;
            Console.Write("Birinchi satrni kiriting: S=");
            S=Console.ReadLine();
            Console.Write("Ikkinchi satrni kiriting: S0=");
            S0=Console.ReadLine();
            for (int i=0;i<S.Length;i++)
            {
                if (S[i]==S0[0]) 
                {
                    f=true;
                    for (int j=0;j<S0.Length;j++,i++)
                    {
                     if (S[i]!=S0[j]) f=false;
                  //   if (j!=S0.Length-1 & i==S.Length-1) {f=false;break;}
                    }
                }
                if (f) n++;
                f=false;
            }
            Console.Write("'"+S+"' satrdagi '"+S0+"' qism satlar soni: "+n);
            Console.ReadKey(true);

		}
	}
}