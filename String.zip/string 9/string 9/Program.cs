﻿/*
 * Created by SharpDevelop.
 * User: User
 * Date: 27/03/2019
 * Time: 19:34
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace string_9
{
	class Program
	{
		public static void Main(string[] args)
		{
			string s, c,y;
			Console.Write("1-satr uchun belgilar kiriting: ");
			s=Console.ReadLine();
			Console.Write("2-satr uchun belgilar kiriting: ");
			c=Console.ReadLine();
			y=string.Join(" ",s,c);
			Console.WriteLine(y);			
			Console.ReadKey(true);
		}
	}
}