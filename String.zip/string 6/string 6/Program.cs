﻿/*
 * Created by SharpDevelop.
 * User: User
 * Date: 26/03/2019
 * Time: 11:11
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace string_6
{
	class Program
	{
		public static void Main(string[] args)
		{
			char b;int a;
			Console.Write("Aniqlanishi kerak bo'lgan belgini kiriting: ");
			b=char.Parse(Console.ReadLine());
			a=(int) b;
			if(a>=48&a<=57) Console.WriteLine("DIGIT");
			el
			{
			if(a>=65&a<=90|a>=97&a<=122) Console.WriteLine("Lotin");
			else
			 {
			 if(a>=1040&a<=1105) Console.WriteLine("Rus");
			 else Console.WriteLine("0");
			 }
			}
			Console.ReadKey(true);
		}
	}
}