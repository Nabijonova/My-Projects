﻿/*
 * Created by SharpDevelop.
 * User: User
 * Date: 12/06/2019
 * Time: 22:52
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace string_33
{
	class Program
	{
		public static void Main(string[] args)
		{
			string S,S0,c=""; bool f=false,b=true; int n=0,i,j=0;
            Console.Write("Birinchi satrni kiriting: S=");
            S=Console.ReadLine();
            Console.Write("Ikkinchi satrni kiriting: S0=");
            S0=Console.ReadLine();
            for (i=0;i<S.Length;i++)
            {
                if (S[i]==S0[0] & b)
                {
                    f=true;n=i;
                    for (j=0;j<S0.Length;j++,i++)
                    {
                        if (S[i]!=S0[j]) {f=false;i--;break;}
                       // if (i==S.Length-1 & j!=S0.Length-1) {f=false;break;}
                    }
                    if (!f) while(n<=i) {c+=S[n];n++;}
                    else {i--;b=false;}
                }
                else c+=S[i];
            }
            Console.Write(c);

			Console.ReadKey(true);
		}
	}
}