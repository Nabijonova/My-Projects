﻿/*
 * Created by SharpDevelop.
 * User: User
 * Date: 13/06/2019
 * Time: 15:14
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace string_30
{
	class Program
	{
		public static void Main(string[] args)
		{
			            string S,S0,c=""; char C; 
            Console.Write("Belgi kiriting: ");
            C=Convert.ToChar(Console.ReadLine());
            Console.Write("Birinchi satrni kiriting: S=");
            S=Console.ReadLine();
            Console.Write("Ikkinchi satrni kiriting: S0=");
            S0=Console.ReadLine();
            for (int i=0;i<S.Length;i++)
            {
                c+=S[i];
                if ((int)S[i]==C) c+=S0;
                
            }
            Console.Write("Hosil bo'lgan yangi satr: "+c);

			Console.ReadKey(true);
		}
	}
}