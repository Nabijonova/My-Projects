﻿/*
 * Created by SharpDevelop.
 * User: User
 * Date: 26/03/2019
 * Time: 18:55
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace string_7
{
	class Program
	{
		public static void Main(string[] args)
		{	
			string s;
			Console.Write("Satr uchun belgilar kiriting: ");
			s=Console.ReadLine();
			Console.WriteLine("Dastlabki belgi: "+s[0]);
			Console.WriteLine("Oxirgi belgi: "+s[s.Length-1]);
			Console.ReadKey(true);
		}
	}
}