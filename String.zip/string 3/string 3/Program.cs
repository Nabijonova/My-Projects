﻿/*
 * Created by SharpDevelop.
 * User: User
 * Date: 26/03/2019
 * Time: 10:43
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace string_3
{
	class Program
	{
		public static void Main(string[] args)
		{
			int a,b;
			char c;
			c=char.Parse(Console.ReadLine());
			a=(int)c-1;
			b=(int)c+1;
			Console.WriteLine(c+" dan oldingi belgi: "+(char) a);
			Console.WriteLine(c+" dan keyingi belgi: "+(char) b);
			Console.ReadKey(true);
		}
	}
}