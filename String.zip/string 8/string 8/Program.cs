﻿/*
 * Created by SharpDevelop.
 * User: User
 * Date: 27/03/2019
 * Time: 18:45
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace string_8
{
	class Program
	{
		public static void Main(string[] args)
		{
			int n; char c;
			Console.Write("n sonini kiriting: n=");
			n=int.Parse(Console.ReadLine());
			Console.Write("c belgini kiriting: c=");
			c=char.Parse(Console.ReadLine());
			Console.WriteLine("Natija:");
			for(int i=0;i<n;i++)
			{Console.Write(c);}
			Console.ReadKey(true);
		}
	}
}