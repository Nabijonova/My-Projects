﻿/*
 * Created by SharpDevelop.
 * User: User
 * Date: 05/06/2019
 * Time: 21:04
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace string_31
{
	class Program
	{
		public static void Main(string[] args)
		{
            string S,S0; bool b=false,f=false;
            Console.Write("Birinchi satrni kiriting: S=");
            S=Console.ReadLine();
            Console.Write("Ikkinchi satrni kiriting: S0=");
            S0=Console.ReadLine();
            for (int i=0;i<S.Length;i++)
            {
                if (S[i]==S0[0]) 
                {
                    f=true;
                    for (int j=1;j<S0.Length;j++,i++)
                    {
                        if (S[i]!=S0[j]) {f=false;i--;break;}
                        if (j!=S0.Length-1 & i==S.Length-1) {f=false;break;}
                    } if (f) b=true;
                }                
            }
//           b=S.Contains(S0);
            if(b) Console.Write("true");
             else Console.Write("false");
            Console.ReadLine();
		}
	}
}