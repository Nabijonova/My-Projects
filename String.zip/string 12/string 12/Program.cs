﻿/*
 * Created by SharpDevelop.
 * User: User
 * Date: 28/03/2019
 * Time: 06:51
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace string_12
{
	class Program
	{
		public static void Main(string[] args)
		{
			try
			{
			string s,P="";int n;
			Console.Write("N sonini kiriting: n=");
			n=int.Parse(Console.ReadLine());
			Console.Write("Satr uchun belgilar kiriting: ");
			s=Console.ReadLine();
			for(int i=0;i<s.Length;i++)
			{
				P+=s[i]; for(int j=0;i<n;j++) {P+="*";}
			}
			Console.WriteLine("Natija: "+P);
			}
			catch(Exception e){Console.WriteLine(e.ToString());}
			Console.ReadKey(true);
		}
	}
}