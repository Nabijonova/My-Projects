﻿/*
 * Created by SharpDevelop.
 * User: User
 * Date: 26/03/2019
 * Time: 10:25
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace string_1
{
	class Program
	{
		public static void Main(string[] args)
		{
			char a;
			a=char.Parse(Console.ReadLine());
			Console.WriteLine((int) a);				
			Console.ReadKey(true);
		}
	}
}