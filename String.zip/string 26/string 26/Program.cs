﻿/*
 * Created by SharpDevelop.
 * User: User
 * Date: 05/06/2019
 * Time: 20:30
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace string_26
{
	class Program
	{
		public static void Main(string[] args)
		{         
			int n; string s,c="";
            Console.Write("Satr kiriting: ");
            s=Console.ReadLine();
            Console.Write("Natural son kiriting: ");
            n=int.Parse(Console.ReadLine());
            if (s.Length<n) c=s+".";
            if (s.Length>n)
              { for (int i=s.Length-1;i>=s.Length-n; i--) c=s[i]+c;}
            Console.Write("Hosil bo'lgan satr: "+c);
            Console.ReadKey(true);
		}
	}
}