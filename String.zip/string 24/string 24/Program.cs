﻿/*
 * Created by SharpDevelop.
 * User: User
 * Date: 05/06/2019
 * Time: 19:24
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace string_24
{
	class Program
	{
		public static void Main(string[] args)
		{
		    int n=0,m; string s,c; 
            Console.Write("Ikkilik sanoq sistemasidagi natural sonni bildiradigan satr kiriting: ");
            s=Console.ReadLine();
            for (int i=0;i<s.Length;i++) 
            {
                m=1;c="";c+=s[i];
                for (int j=1;j<s.Length-i;j++) m*=2;
                n+=Convert.ToInt32(c)*m;
            }
            Console.Write("Bu son o'nlik sanoq sistemasida: "+n);

			Console.ReadKey(true);
		}
	}
}