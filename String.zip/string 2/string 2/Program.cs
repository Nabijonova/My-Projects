﻿/*
 * Created by SharpDevelop.
 * User: User
 * Date: 26/03/2019
 * Time: 10:35
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace string_2
{
	class Program
	{
		public static void Main(string[] args)
		{
			float a;
			a=float.Parse(Console.ReadLine());
			Console.WriteLine((char) a);
			Console.ReadKey(true);
		}
	}
}