﻿/*
 * Created by SharpDevelop.
 * User: User
 * Date: 28/04/2019
 * Time: 20:39
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.IO;

namespace fayl_21
{
	class Program
	{
		public static void Main(string[] args)
		{
		    string s,k,c; int i; bool v=false,h=false;
            Console.Write("Berilgan fayl nomi: s=");
            s=Console.ReadLine(); 
            Console.Write("Berilgan fayl nomi: s=");
            c=Console.ReadLine();
            StreamReader a=File.OpenText(@"c:\Intel\"+s);
            k=a.ReadLine();
            char [] m={' '};
            string [] b=k.Split(m,StringSplitOptions.RemoveEmptyEntries);
            int [] p=new int[b.Length];
            for(i=2;i<b.Length; i++)
            {    if(Convert.ToInt16(b[i-1])>Convert.ToInt16(b[i-2])) v=true;
                if(Convert.ToInt16(b[i-1])>Convert.ToInt16(b[i-2])&Convert.ToInt16(b[i-1])>Convert.ToInt16(b[i])&v)
                {p[i-1]=i-1; v=false;h=true;}
            }
            if(!h) Console.WriteLine("Lokal max mavjud emas!");
            StreamWriter d=File.CreateText(@"c:\Intel\"+c);
            for(i=0;i<b.Length;i++)
            d.Write(p[i]+" ");
            d.Close();
			Console.ReadKey(true);
		}
	}
}