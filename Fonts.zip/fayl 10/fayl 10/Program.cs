﻿/*
 * Created by SharpDevelop.
 * User: User
 * Date: 28/04/2019
 * Time: 15:13
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.IO;

namespace fayl_10
{
	class Program
	{
		public static void Main(string[] args)
		{
			string k,s,w,q="";
			Console.Write("Berilgan fayl nomi: s=");
			s=Console.ReadLine();
			Console.Write("Yangi fayl nomi: w=");
			w=Console.ReadLine();
			StreamReader a=File.OpenText(@"c:\Intel\"+s);
			k=a.ReadLine();
		    char [] m={' '};
			string [] b=k.Split(m,StringSplitOptions.RemoveEmptyEntries);
			for(int i=0; i<b.Length;i++)
			 q=b[i]+" "+q;
			StreamWriter d=File.CreateText(@"c:\Intel\"+w);
			d.WriteLine(q);  d.Close();
			Console.ReadKey(true);
		}
	}
}