﻿/*
 * Created by SharpDevelop.
 * User: User
 * Date: 28/04/2019
 * Time: 18:46
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.IO;

namespace fayl_17
{
	class Program
	{
		public static void Main(string[] args)
		{
			string s,k,c;int n=1;
			Console.Write("Berilgan fayl nomi: s=");
			s=Console.ReadLine();
			Console.Write("Yangi fayl nomi: c=");
			c=Console.ReadLine();
			StreamReader a=File.OpenText(@"c:\Intel\"+s);
			k=a.ReadLine();
		    char [] m={' '};
			string [] b=k.Split(m,StringSplitOptions.RemoveEmptyEntries);
			StreamWriter d=File.CreateText(@"c:\Intel\"+c);
			for(int i=1; i<b.Length; i++)
			{
			  if(b[i]==b[i-1]) n++;
			  else {d.Write(n+" "); n=1;}
			} 
			 d.Write(n+" "); n=0;
		    d.Close();
			Console.ReadKey(true);
		}
	}
}