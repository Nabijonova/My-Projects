﻿/*
 * Created by SharpDevelop.
 * User: User
 * Date: 28/04/2019
 * Time: 15:56
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.IO;

namespace fayl_13
{
	class Program
	{
		public static void Main(string[] args)
		{
			string k,s,w,j,q="";
			Console.Write("Berilgan fayl nomi: s=");
			s=Console.ReadLine();
			Console.Write("Yangi fayl nomi: w=");
			w=Console.ReadLine();
			Console.Write("Yangi fayl nomi: j=");
			j=Console.ReadLine();
			StreamReader a=File.OpenText(@"c:\Intel\"+s);
			k=a.ReadLine();
		    char [] m={' '};
			string [] b=k.Split(m,StringSplitOptions.RemoveEmptyEntries);
			
			for(int i=0; i<b.Length;i++)
			{if(Convert.ToInt16(b[i])>0)  q=b[i]+" "+q;}
			StreamWriter d=File.CreateText(@"c:\Intel\"+w);
			d.WriteLine(q);  d.Close();
			q="";
			for(int i=0; i<b.Length;i++)
			{if(Convert.ToInt16(b[i])<0)  q=b[i]+" "+q;}
			StreamWriter c=File.CreateText(@"c:\Intel\"+j);
			c.WriteLine(q);  c.Close();
			Console.ReadKey(true);
		}
	}
}