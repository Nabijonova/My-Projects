﻿/*
 * Created by SharpDevelop.
 * User: User
 * Date: 28/04/2019
 * Time: 16:16
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.IO;

namespace fayl_15
{
	class Program
	{
		public static void Main(string[] args)
		{			
			string s,k;double p=0;
			Console.Write("Berilgan fayl nomi: s=");
			s=Console.ReadLine();
			StreamReader a=File.OpenText(@"c:\Intel\"+s);
			k=a.ReadLine();
		    char [] m={' '};
			string [] b=k.Split(m,StringSplitOptions.RemoveEmptyEntries);
			for(int i=0; i<b.Length; i+=2)
			{p+=Convert.ToInt16(b[i]);}
			Console.WriteLine("Natija: "+p);
			Console.ReadKey(true);
		}
	}
}