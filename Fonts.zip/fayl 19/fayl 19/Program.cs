﻿/*
 * Created by SharpDevelop.
 * User: User
 * Date: 28/04/2019
 * Time: 19:45
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.IO;

namespace fayl_19
{
	class Program
	{
		public static void Main(string[] args)
		{
			string s,k;int p=0,i; bool v=false,h=true;
			Console.Write("Berilgan fayl nomi: s=");
			s=Console.ReadLine();
			StreamReader a=File.OpenText(@"c:\Intel\"+s);
			k=a.ReadLine();
		    char [] m={' '};
			string [] b=k.Split(m,StringSplitOptions.RemoveEmptyEntries);
			for(i=2;i<b.Length; i++)
			{	if(Convert.ToInt16(b[i-1])>Convert.ToInt16(b[i-2])) v=true;
				if(Convert.ToInt16(b[i-1])>Convert.ToInt16(b[i-2])&Convert.ToInt16(b[i-1])>Convert.ToInt16(b[i])&v)
					{p=i-1; v=false;h=false;}
		    }
			if(h) Console.WriteLine("Lokal max mavjud emas!");
			Console.WriteLine(b[p]);
			Console.ReadKey(true);
		}
	}
}