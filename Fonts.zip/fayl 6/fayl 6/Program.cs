﻿/*
 * Created by SharpDevelop.
 * User: User
 * Date: 27/04/2019
 * Time: 22:22
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.IO;

namespace fayl_6
{
	class Program
	{
		public static void Main(string[] args)
		{
			string s; int k,n=0;
			Console.Write("s=");
			s=Console.ReadLine();
			Console.Write("k=");
			k=int.Parse(Console.ReadLine());
			StreamReader a=File.OpenText(@"c:\Intel\"+s);
			while((s=a.ReadLine())!=null)
			{
				char [] m={' '};
				string [] b=s.Split(m,StringSplitOptions.RemoveEmptyEntries);
				if(n+b.Length>=k) { Console.WriteLine(b[k-1]);break;} else Console.WriteLine("-1");
				n+=b.Length;
			}
			Console.ReadKey(true);
		}
	}
} 