﻿/*
 * Created by SharpDevelop.
 * User: User
 * Date: 28/04/2019
 * Time: 20:26
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.IO;

namespace fayl_20
{
	class Program
	{
		public static void Main(string[] args)
		{
			string s,k;int p=0,i;bool h=true;
			Console.Write("Berilgan fayl nomi: s=");
			s=Console.ReadLine();
			StreamReader a=File.OpenText(@"c:\Intel\"+s);
			k=a.ReadLine();
		    char [] m={' '};
			string [] b=k.Split(m,StringSplitOptions.RemoveEmptyEntries);
			for(i=2;i<b.Length; i++)
			{	
				if(Convert.ToInt16(b[i-1])>Convert.ToInt16(b[i-2])&Convert.ToInt16(b[i-1])>Convert.ToInt16(b[i]))
				{p++;h=false;}
		    }
			if(h) Console.WriteLine("Lokal extrimumlari mavjud emas!");
			if(!h) Console.WriteLine("Lokal extrimumlari soni: "+p);
			Console.ReadKey(true);
		}
	}
}